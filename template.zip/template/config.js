module.exports = {

    token: "Your bot token here"
}